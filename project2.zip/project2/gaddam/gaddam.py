def get_hash_value(this_str):
    """
    Get the hash value
    :param this_str: String
    :return: sum of ASCII values of all the upper case characters in a string
    """
    return sum([ord(each_char) for each_char in this_str if ('A' <= each_char <= 'Z')])


def get_hash_string(this_str):
    """
    Get the hash string
    :param this_str: String
    :return: String which contains upper case characters
    """
    return ''.join([each_char for each_char in this_str if ('A' <= each_char <= 'Z')])


def get_index_by_modulo(this_str, modulo_val=13):
    """
    Get the index
    :param this_str: String
    :param modulo_val: modulo value = 13
    :return: (hash value of the string) % modulo value
    """
    return get_hash_value(this_str) % modulo_val


def get_initial_table(tab_size=13):
    """
    Get the initial table with size 13
    :param tab_size: 13
    :return: table containing None in 13 places
    """
    return [None] * tab_size


def update_table_entry(table, this_password, modulo_val=13):
    """
    Update the table entry
    :param table: Table
    :param this_password: Password entered
    :param modulo_val: 13
    :return: None
    """
    # Storing this_password from get_index_by_modulo to this_index
    this_index = get_index_by_modulo(this_password)
    # Storing this_password from get_hash_string to this_hashed_str
    this_hashed_str = get_hash_string(this_password)
    if this_hashed_str:
        while table[this_index] is not None:
            # Increase the index value by 1 whenever the index value is not none
            this_index = (this_index + 1) % modulo_val
        table[this_index] = this_hashed_str
    else:
        # Printing error message when password does not contain atleast one Upper case character
        print("Error: Empty hashed password encountered. Password must have at least one uppercase alphabet")


def add_password_from_dictionary_text_to_table(table, dictionary_txt, modulo_val=13, read_password_limit=10):
    """
    Adding password from input file to table
    :param table: Table
    :param dictionary_txt: Input File
    :param modulo_val: 13
    :param read_password_limit: 10
    :return: None
    """
    # Reading input file
    with open(dictionary_txt, 'r') as f:
        # Returns a password list containing each line in the input file as a list item
        password_list = f.readlines()
    for i in range(read_password_limit):
        # Storing each password from list of passwords in this_password
        this_password = password_list[i]
        if read_password_limit >= modulo_val:
            # Printing an error message when password limit exceeds modulo value
            print("Error: Exiting...Table size less than the modulo value")
            return
        # Update table
        update_table_entry(table, this_password)


if __name__ == "__main__":
    # Get password input from user
    password_input = input("Enter new password:")
    password_accepted = False
    m_table = get_initial_table()
    # Adding password from input text to the table
    add_password_from_dictionary_text_to_table(m_table, "dictionary.txt")
    while not password_accepted:
        hashed_string = get_hash_string(password_input)
        if hashed_string in m_table:
            # Printing an error message
            password_input = input("The password you just entered is unacceptable, enter new password:")
        else:
            # Printing that the password has been updated
            print("Your password has been changed.")
            update_table_entry(m_table, password_input)
            # Printing updated table
            print("Updated table : {}".format(m_table))
            password_accepted = True
